import React from "react"

function NotFound() {
    return <div>
        Looks like you are Lost
        <br />
        <button onClick={() => {

        }}>Go To Home</button>
    </div>
}

export default NotFound